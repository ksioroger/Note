package controle;

import interfaces.Atalhos;

/**
 *
 * @author cassi
 */
public class controladorAtalhos {
    public controladorAtalhos() {
        Atalhos janelaAtalhos =  new Atalhos();
        janelaAtalhos.setLocationRelativeTo(null);
        janelaAtalhos.setResizable(false);
        janelaAtalhos.setVisible(true);  
    }
}
